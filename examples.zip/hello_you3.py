'''Hello to you!  Illustrates format with {} in print.
'''

person = input('Enter your name: ')
greeting = 'Hello, {}!'.format(person)
print(greeting)
