def listOnOneLine(items):
    for item in items:
        print(item, end=' ')

listOnOneLine(['apple', 'banana', 'pear'])
print('This may not be what you expected!')
