'''Two numeric inputs, explicit sum'''

x = int(input("Enter an integer: "))
y = int(input("Enter another integer: "))
sum = x+y
print('The sum of ', x, ' and ', y, ' is ', sum, '.', sep='')
