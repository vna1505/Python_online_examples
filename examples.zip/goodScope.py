'''A change to badScope.py avoiding any error by passing a parameter'''

def main():
    x = 3
    f(x)

def f(x):
    print(x)  

main()
